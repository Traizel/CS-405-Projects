// BufferOverflow.cpp: safely collect input without changing the account number.
#include <cstddef>
#include <iostream>
#include <string>

// Notify the caller of rejection instead of silently accepting truncated input.
enum class InputStatus { success, too_long, empty, stream_error };

// An array reference lets the compiler deduce capacity for any char array size.
template <std::size_t Capacity>
InputStatus read_input(std::istream& input, char (&buffer)[Capacity])
{
    static_assert(Capacity > 0, "Input buffer needs a string terminator.");
    std::size_t length = 0;
    bool too_long = false;
    char character = '\0';
    buffer[0] = '\0';

    // Read the entire line, including spaces. Never write beyond Capacity - 1.
    // Continue consuming an oversized line so leftover input cannot be reused.
    while (input.get(character))
    {
        if (character == '\n')
        {
            break;
        }
        if (length < Capacity - 1)
        {
            buffer[length++] = character;
        }
        else
        {
            too_long = true;
        }
    }
    buffer[length] = '\0'; // Reserve one byte for the C-string terminator.

    if (input.bad() || (input.fail() && !input.eof()))
    {
        buffer[0] = '\0';
        return InputStatus::stream_error;
    }
    if (too_long)
    {
        buffer[0] = '\0'; // Reject the whole value; do not use a truncated one.
        return InputStatus::too_long;
    }
    return length == 0 ? InputStatus::empty : InputStatus::success;
}

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // Preserve the original account variable and its position directly before input.
    const std::string account_number = "CharlieBrown42";
    char user_input[20];
    std::cout << "Enter a value: ";
    const InputStatus status = read_input(std::cin, user_input);

    // The calling function explicitly reports why input was rejected.
    switch (status)
    {
    case InputStatus::success:
        std::cout << "You entered: " << user_input << std::endl;
        break;
    case InputStatus::too_long:
        std::cout << "Buffer overflow prevented: input exceeds "
                  << sizeof(user_input) - 1 << " characters. Value rejected."
                  << std::endl;
        break;
    case InputStatus::empty:
        std::cout << "No value entered. Value rejected." << std::endl;
        break;
    case InputStatus::stream_error:
        std::cout << "Input error. Value rejected." << std::endl;
        break;
    }

    std::cout << "Account Number = " << account_number << std::endl;
    // Nonzero status also notifies a shell or other process of rejected input.
    return status == InputStatus::success ? 0 : 1;
}
