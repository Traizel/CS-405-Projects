// SQLInjection.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <algorithm>
#include <cctype>   // Safe character conversion for token normalization.
#include <cstdlib>  // Declarations used by the supplied random test driver.
#include <ctime>    // Declaration of time used by the supplied main function.
#include <regex>    // SQL token recognition for the assignment-specific guard.
#include <string>
#include <iostream>
#include <locale>
#include <tuple>
#include <vector>

#include "sqlite3.h"

// DO NOT CHANGE
typedef std::tuple<std::string, std::string, std::string> user_record;
const std::string str_where = " where ";

// DO NOT CHANGE
static int callback(void* possible_vector, int argc, char** argv, char** azColName)
{
  if (possible_vector == NULL)
  { // no vector passed in, so just display the results
    for (int i = 0; i < argc; i++) 
    {
      std::cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << std::endl;
    }
    std::cout << std::endl;
  }
  else
  {
    std::vector< user_record >* rows =
      static_cast<std::vector< user_record > *>(possible_vector);

    rows->push_back(std::make_tuple(argv[0], argv[1], argv[2]));
  }
  return 0;
}

// DO NOT CHANGE
bool initialize_database(sqlite3* db)
{
  char* error_message = NULL;
  std::string sql = "CREATE TABLE USERS(" \
    "ID INT PRIMARY KEY     NOT NULL," \
    "NAME           TEXT    NOT NULL," \
    "PASSWORD       TEXT    NOT NULL);";

  int result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Failed to create USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }
  std::cout << "USERS table created." << std::endl;

  // insert some dummy data
  sql = "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (1, 'Fred', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (2, 'Barney', 'Rubble');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (3, 'Wilma', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (4, 'Betty', 'Rubble');";

  result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Data failed to insert to USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }

  return true;
}

// Keep scanning separate from execution so the guard can be tested independently.
// This is an assignment-specific detector, not a complete SQL parser or firewall.
namespace
{
  struct SqlToken
  {
    std::string text;
    bool literal;
  };

  bool contains_suspected_injection(const std::string& sql)
  {
    // Match complete quoted values before looking for keywords. Doubled quote
    // escapes stay inside their token, so text such as 'or 1=1' is only data.
    // SQL comments are discarded as tokens, not removed by joining their neighbors.
    // Double quotes are conservatively treated as literals because the bundled
    // SQLite also permits legacy double-quoted strings. Backticks/brackets are IDs.
    static const std::regex token_pattern(
      R"SQL((\s+|--[^\r\n]*|/\*[\s\S]*?\*/)|('(?:''|[^'])*'|"(?:""|[^"])*")|(`(?:``|[^`])*`|\[[^\]]*\])|(0[xX][0-9a-fA-F]+|(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?)|([A-Za-z_\x80-\xff][A-Za-z_0-9$\x80-\xff]*)|(==|[\s\S]))SQL");

    std::vector<SqlToken> tokens;
    for (std::sregex_iterator it(sql.begin(), sql.end(), token_pattern), end;
         it != end; ++it)
    {
      const std::smatch& match = *it;
      if (match[1].matched) continue; // Ignore whitespace and comments.
      std::string text = match.str();
      if (match[5].matched)
      {
        std::transform(text.begin(), text.end(), text.begin(),
          [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
      }
      // Numeric and quoted literals are sufficient for the required attack.
      // Also recognize common SQLite constant keywords for defensive coverage.
      const bool literal = match[2].matched || match[4].matched ||
        (match[5].matched && (text == "null" || text == "true" ||
          text == "false" || text == "current_date" ||
          text == "current_time" || text == "current_timestamp"));
      tokens.push_back({text, literal});
    }

    for (std::size_t i = 0; i < tokens.size(); ++i)
    {
      if (tokens[i].text != "or" || tokens[i].literal) continue;
      std::size_t j = i + 1;
      // Permit parentheses and unary signs around numeric operands.
      while (j < tokens.size() && (tokens[j].text == "(" ||
             tokens[j].text == "+" || tokens[j].text == "-")) ++j;
      if (j == tokens.size() || !tokens[j].literal) continue;
      ++j;
      while (j < tokens.size() && tokens[j].text == ")") ++j;
      if (j == tokens.size() || (tokens[j].text != "=" &&
                                tokens[j].text != "==")) continue;
      ++j;
      while (j < tokens.size() && (tokens[j].text == "(" ||
             tokens[j].text == "+" || tokens[j].text == "-")) ++j;
      if (j < tokens.size() && tokens[j].literal)
      {
        // Reject all OR literal=literal comparisons, even unequal literals.
        // This avoids conversion/rounding errors and catches equivalent numeric
        // spellings such as 2=2.0 without evaluating attacker-controlled SQL.
        return true;
      }
    }
    return false;
  }
}

bool run_query(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  // Clear before validation so a blocked call cannot expose prior query results.
  records.clear();
  if (contains_suspected_injection(sql))
  {
    std::cout << "SECURITY: Suspected SQL injection (OR literal=literal). "
              << "Query blocked before execution; 0 records returned." << std::endl;
    return false; // Fail closed: never execute or partially repair this query.
  }

  char* error_message = nullptr;
  if (sqlite3_exec(db, sql.c_str(), callback, &records, &error_message) != SQLITE_OK)
  {
    std::cout << "Data failed to be queried from USERS table. ERROR = "
              << (error_message ? error_message : sqlite3_errmsg(db)) << std::endl;
    sqlite3_free(error_message);
    records.clear(); // Discard any partial results on an execution error.
    return false;
  }
  return true;
}

// DO NOT CHANGE
bool run_query_injection(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  std::string injectedSQL(sql);
  std::string localCopy(sql);

  // we work on the local copy because of the const
  std::transform(localCopy.begin(), localCopy.end(), localCopy.begin(), ::tolower);
  if(localCopy.find_last_of(str_where) >= 0)
  { // this sql has a where clause
    if(localCopy.back() == ';')
    { // smart SQL developer terminated with a semicolon - we can fix that!
      injectedSQL.pop_back();
    }

    switch (rand() % 4)
    {
    case 1:
      injectedSQL.append(" or 2=2;");
      break;
    case 2:
      injectedSQL.append(" or 'hi'='hi';");
      break;
    case 3:
      injectedSQL.append(" or 'hack'='hack';");
      break;
    case 0:
    default:
      injectedSQL.append(" or 1=1;");
      break;
    }
  }
  
  return run_query(db, injectedSQL, records);
}


// DO NOT CHANGE
void dump_results(const std::string& sql, const std::vector< user_record >& records)
{
  std::cout << std::endl << "SQL: " << sql << " ==> " << records.size() << " records found." << std::endl;

  for (auto record : records)
  {
    std::cout << "User: " << std::get<1>(record) << " [UID=" << std::get<0>(record) << " PWD=" << std::get<2>(record) << "]" << std::endl;
  }
}

// DO NOT CHANGE
void run_queries(sqlite3* db)
{
  char* error_message = NULL;

  std::vector< user_record > records;

  // query all
  std::string sql = "SELECT * from USERS";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  query 1
  sql = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred'";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  run query 1 with injection 5 times
  for (auto i = 0; i < 5; ++i)
  {
    if (!run_query_injection(db, sql, records)) continue;
    dump_results(sql, records);
  }

}

// You can change main by adding stuff to it, but all of the existing code must remain, and be in the
// in the order called, and with none of this existing code placed into conditional statements
int main()
{
  // initialize random seed:
  srand(time(nullptr));

  int return_code = 0;
  std::cout << "SQL Injection Example" << std::endl;

  // the database handle
  sqlite3* db = NULL;
  char* error_message = NULL;

  // open the database connection
  int result = sqlite3_open(":memory:", &db);

  if(result != SQLITE_OK)
  {
    std::cout << "Failed to connect to the database and terminating. ERROR=" << sqlite3_errmsg(db) << std::endl;
    return -1;
  }

  std::cout << "Connected to the database." << std::endl;

  // initialize our database
  if(!initialize_database(db))
  {
    std::cout << "Database Initialization Failed. Terminating." << std::endl;
    return_code = -1;
  }
  else
  {
    run_queries(db);
  }

  // close the connection if opened
  if(db != NULL)
  {
    sqlite3_close(db);
  }

  return return_code;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
