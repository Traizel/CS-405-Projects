// Separate deterministic tests; the assignment's protected driver is unchanged.
#define main assignment_main
#include "SQLInjection.cpp"
#undef main
#include <sstream>

int main()
{
  sqlite3* db = nullptr;
  if (sqlite3_open(":memory:", &db) != SQLITE_OK) return 1;
  if (!initialize_database(db)) { sqlite3_close(db); return 1; }
  struct Test { const char* label; std::string sql; bool allowed; std::size_t rows; };
  const std::string base = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred'";
  const std::vector<Test> tests = {
    {"All users", "SELECT * FROM USERS", true, 4},
    {"Fred only", base, true, 1},
    {"Legitimate OR with columns", base + " OR NAME='Wilma'", true, 2},
    {"Attack text inside a string", "SELECT * FROM USERS WHERE NAME='or 1=1'", true, 0},
    {"Attack text inside a comment", base + " /* or 1=1 */", true, 1},
    {"Escaped apostrophe in data", "SELECT * FROM USERS WHERE NAME='O''Brien or 1=1'", true, 0},
    {"Keyword within identifier", "SELECT * FROM USERS AS origin", true, 4},
    {"Quoted identifier named or", "SELECT * FROM USERS AS \"or\"", true, 4},
    {"Numeric one", base + " or 1=1;", false, 0},
    {"Numeric two", base + " or 2=2;", false, 0},
    {"Quoted hi", base + " or 'hi'='hi';", false, 0},
    {"Quoted hack", base + " or 'hack'='hack';", false, 0},
    {"Other integer", base + " OR 87654=87654", false, 0},
    {"Negative integer", base + " OR -12=-12", false, 0},
    {"Positive sign", base + " OR +12=12", false, 0},
    {"Decimal", base + " OR 3.125=3.125", false, 0},
    {"Leading decimal point", base + " OR .5=.5", false, 0},
    {"Scientific notation", base + " OR 1e3=1000", false, 0},
    {"Hexadecimal", base + " OR 0xFF=255", false, 0},
    {"Equivalent numeric spellings", base + " OR 2=2.0", false, 0},
    {"Large integer literal", base + " OR 999999999999999999999=999999999999999999999", false, 0},
    {"Mixed case and whitespace", base + " oR\n\t 9 = 9 ;", false, 0},
    {"Block comment separators", base + " OR/**/7/*a*/=/*b*/7", false, 0},
    {"Line comment separator", base + " OR-- test\n8=8", false, 0},
    {"Parenthesized comparison", base + " OR ((4=4))", false, 0},
    {"Parenthesized operands", base + " OR (4)=(4)", false, 0},
    {"Double equals", base + " OR 5==5", false, 0},
    {"Empty string", base + " OR ''=''", false, 0},
    {"Escaped quote literal", base + " OR 'it''s'='it''s'", false, 0},
    {"Legacy double quoted string", base + " OR \"hello\"=\"hello\"", false, 0},
    {"Conservative unequal literals", base + " OR 1=2", false, 0},
    {"Boolean constants", base + " OR TRUE=TRUE", false, 0},
    {"Syntax error clears results", "SELECT * FROM missing_table", false, 0}
  };
  int failed = 0;
  for (const auto& test : tests)
  {
    std::vector<user_record> records = {std::make_tuple("99", "stale", "stale")};
    std::ostringstream captured;
    auto* original = std::cout.rdbuf(captured.rdbuf());
    const bool allowed = run_query(db, test.sql, records);
    std::cout.rdbuf(original);
    const bool pass = allowed == test.allowed && records.size() == test.rows &&
      (test.allowed || !captured.str().empty());
    std::cout << (pass ? "PASS " : "FAIL ") << test.label << '\n';
    if (!pass) ++failed;
  }
  // Exercise many numeric values so the guard cannot pass by hardcoding 1 or 2.
  for (int value = -100; value <= 100; ++value)
  {
    const std::string literal = std::to_string(value);
    if (!contains_suspected_injection(base + " OR " + literal + "=" + literal)) ++failed;
  }
  std::cout << "Numeric sweep: 201 values checked.\n";
  std::cout << "Result: " << tests.size() + 201 << " checks, " << failed << " failures.\n";
  sqlite3_close(db);
  return failed == 0 ? 0 : 1;
}
